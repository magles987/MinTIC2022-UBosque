//rudimentaria sesion actual

/**contiene la cedula del usuario actual de la aplicacion */
var cedulaUsuarioActual = -1;
/**
*Ya casi
*/